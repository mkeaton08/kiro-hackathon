"""
CTF Mini-Game Backend
A 5-level (+bonus) Capture The Flag challenge game backend
Built with Flask for hackathon use
"""

from flask import Flask, request, jsonify, send_file, session
from flask_cors import CORS
import uuid
import os
import json
from datetime import datetime
import base64

app = Flask(__name__)
app.secret_key = 'ctf_hackathon_secret_key_2024'  # Change this in production
CORS(app)  # Enable CORS for frontend integration

# In-memory storage for user sessions and progress
user_sessions = {}
user_progress = {}

# Challenge flags - in production, these would be in environment variables
FLAGS = {
    1: "kir0{hidden_in_plain_sight}",
    2: "kir0{log_hunter}",
    3: "kir0{exif_detective}",
    4: "kir0{packet_master}",
    5: "kir0{logic_wizard}",
    6: "kir0{no_access_controls}"
}

# Mock file system for Level 1
MOCK_FILESYSTEM = {
    "/": ["home", "var", "etc", ".secret_dir"],
    "/home": ["user", "admin"],
    "/home/user": ["documents", "downloads"],
    "/home/user/documents": ["readme.txt", "notes.txt"],
    "/home/user/downloads": ["file1.zip", "file2.pdf"],
    "/home/admin": ["config.ini"],
    "/var": ["log", "www"],
    "/var/log": ["access.log", "error.log"],
    "/var/www": ["index.html", "style.css"],
    "/etc": ["passwd", "hosts"],
    "/.secret_dir": ["flag.txt", "hidden_config.json"]
}

MOCK_FILES = {
    "/home/user/documents/readme.txt": "Welcome to the system! Nothing interesting here.",
    "/home/user/documents/notes.txt": "Remember to check hidden directories...",
    "/home/admin/config.ini": "[admin]\nuser=admin\npass=secret123",
    "/var/log/access.log": "Standard access log entries...",
    "/var/log/error.log": "No errors found.",
    "/var/www/index.html": "<html><body>Welcome</body></html>",
    "/etc/passwd": "root:x:0:0:root:/root:/bin/bash\nuser:x:1000:1000:user:/home/user:/bin/bash",
    "/etc/hosts": "127.0.0.1 localhost",
    "/.secret_dir/flag.txt": FLAGS[1],
    "/.secret_dir/hidden_config.json": '{"secret": "configuration", "flag": "' + FLAGS[1] + '"}'
}

def get_or_create_session():
    """Get existing session or create new one"""
    if 'user_id' not in session:
        session['user_id'] = str(uuid.uuid4())
        user_sessions[session['user_id']] = {
            'created_at': datetime.now().isoformat(),
            'current_level': 1,
            'completed_levels': []
        }
        user_progress[session['user_id']] = {
            'level_1': False,
            'level_2': False,
            'level_3': False,
            'level_4': False,
            'level_5': False,
            'level_6': False
        }
    
    return session['user_id']

@app.route('/api/session', methods=['GET'])
def get_session_info():
    """Get current session information"""
    user_id = get_or_create_session()
    return jsonify({
        'user_id': user_id,
        'session_info': user_sessions.get(user_id, {}),
        'progress': user_progress.get(user_id, {})
    })

@app.route('/api/challenge/1', methods=['GET'])
def challenge_1():
    """Level 1: Terminal Recon - Mock filesystem exploration"""
    user_id = get_or_create_session()
    
    return jsonify({
        'level': 1,
        'title': 'Terminal Recon',
        'description': 'Navigate the filesystem to find the hidden flag. Use /api/explore/<path> to navigate.',
        'hint': 'Look for hidden directories that start with a dot (.)',
        'available_commands': ['ls', 'cd', 'cat'],
        'current_directory': '/',
        'files': MOCK_FILESYSTEM['/']
    })

@app.route('/api/explore/<path:directory>', methods=['GET'])
def explore_directory(directory):
    """Explore mock filesystem for Level 1"""
    user_id = get_or_create_session()
    
    # Normalize path
    if not directory.startswith('/'):
        directory = '/' + directory
    
    if directory in MOCK_FILESYSTEM:
        return jsonify({
            'current_directory': directory,
            'files': MOCK_FILESYSTEM[directory],
            'message': f'Contents of {directory}'
        })
    else:
        return jsonify({
            'error': 'Directory not found',
            'current_directory': directory
        }), 404

@app.route('/api/read/<path:filepath>', methods=['GET'])
def read_file(filepath):
    """Read mock files for Level 1"""
    user_id = get_or_create_session()
    
    # Normalize path
    if not filepath.startswith('/'):
        filepath = '/' + filepath
    
    if filepath in MOCK_FILES:
        return jsonify({
            'filepath': filepath,
            'content': MOCK_FILES[filepath],
            'message': f'Contents of {filepath}'
        })
    else:
        return jsonify({
            'error': 'File not found',
            'filepath': filepath
        }), 404

@app.route('/api/challenge/2', methods=['GET'])
def challenge_2():
    """Level 2: Log File Leak - Serve fake webserver.log"""
    user_id = get_or_create_session()
    
    # Check if user completed level 1
    if not user_progress[user_id]['level_1']:
        return jsonify({
            'error': 'Complete Level 1 first',
            'redirect': '/api/challenge/1'
        }), 403
    
    # Generate fake log entries with embedded flag
    log_entries = [
        '192.168.1.100 - - [06/Aug/2024:10:15:23 +0000] "GET /index.html HTTP/1.1" 200 1234',
        '192.168.1.101 - - [06/Aug/2024:10:16:45 +0000] "GET /about.html HTTP/1.1" 200 567',
        '192.168.1.102 - - [06/Aug/2024:10:17:12 +0000] "POST /login HTTP/1.1" 302 0',
        f'192.168.1.103 - - [06/Aug/2024:10:18:33 +0000] "GET /search?q={FLAGS[2]} HTTP/1.1" 200 890',
        '192.168.1.104 - - [06/Aug/2024:10:19:55 +0000] "GET /contact.html HTTP/1.1" 200 445',
        '192.168.1.105 - - [06/Aug/2024:10:20:17 +0000] "GET /favicon.ico HTTP/1.1" 404 0'
    ]
    
    return jsonify({
        'level': 2,
        'title': 'Log File Leak',
        'description': 'Analyze the webserver log file to find the flag hidden in a suspicious query.',
        'hint': 'Look for unusual query parameters in GET requests',
        'log_entries': log_entries,
        'download_url': '/api/download/webserver.log'
    })

@app.route('/api/download/webserver.log', methods=['GET'])
def download_webserver_log():
    """Download the webserver log file for Level 2"""
    log_content = f"""192.168.1.100 - - [06/Aug/2024:10:15:23 +0000] "GET /index.html HTTP/1.1" 200 1234
192.168.1.101 - - [06/Aug/2024:10:16:45 +0000] "GET /about.html HTTP/1.1" 200 567
192.168.1.102 - - [06/Aug/2024:10:17:12 +0000] "POST /login HTTP/1.1" 302 0
192.168.1.103 - - [06/Aug/2024:10:18:33 +0000] "GET /search?q={FLAGS[2]} HTTP/1.1" 200 890
192.168.1.104 - - [06/Aug/2024:10:19:55 +0000] "GET /contact.html HTTP/1.1" 200 445
192.168.1.105 - - [06/Aug/2024:10:20:17 +0000] "GET /favicon.ico HTTP/1.1" 404 0"""
    
    # Create temporary file
    with open('webserver.log', 'w') as f:
        f.write(log_content)
    
    return send_file('webserver.log', as_attachment=True, download_name='webserver.log')

@app.route('/api/challenge/3', methods=['GET'])
def challenge_3():
    """Level 3: Forensic Photo Hunt - EXIF metadata challenge"""
    user_id = get_or_create_session()
    
    # Check if user completed level 2
    if not user_progress[user_id]['level_2']:
        return jsonify({
            'error': 'Complete Level 2 first',
            'redirect': '/api/challenge/2'
        }), 403
    
    return jsonify({
        'level': 3,
        'title': 'Forensic Photo Hunt',
        'description': 'Download the image and examine its EXIF metadata to find the flag.',
        'hint': 'The flag is hidden in the Author field of the image metadata',
        'image_url': '/api/download/evidence.jpg',
        'tools_needed': 'EXIF reader (exiftool, online EXIF viewers, etc.)'
    })

@app.route('/api/download/evidence.jpg', methods=['GET'])
def download_evidence_image():
    """Serve the evidence image with EXIF data containing the flag"""
    # For this demo, we'll create a simple response indicating where the image would be
    # In a real implementation, you'd serve an actual image file with EXIF data
    return jsonify({
        'message': 'Image download simulation',
        'note': 'In a real implementation, this would serve a JPEG file',
        'exif_simulation': {
            'Camera': 'Canon EOS 5D',
            'Date': '2024:08:06 10:30:00',
            'Author': FLAGS[3],  # Flag hidden in Author field
            'GPS': 'N/A'
        },
        'hint': 'Use exiftool or similar to extract metadata'
    })
@app.route('/api/challenge/4', methods=['GET'])
def challenge_4():
    """Level 4: Packet Sniff Surprise - PCAP file analysis"""
    user_id = get_or_create_session()
    
    # Check if user completed level 3
    if not user_progress[user_id]['level_3']:
        return jsonify({
            'error': 'Complete Level 3 first',
            'redirect': '/api/challenge/3'
        }), 403
    
    return jsonify({
        'level': 4,
        'title': 'Packet Sniff Surprise',
        'description': 'Download and analyze the packet capture file to find the flag in an HTTP request.',
        'hint': 'Look for HTTP GET requests containing the flag',
        'pcap_url': '/api/download/network_capture.pcap',
        'tools_needed': 'Wireshark, tcpdump, or similar packet analysis tools'
    })

@app.route('/api/download/network_capture.pcap', methods=['GET'])
def download_pcap():
    """Serve the PCAP file simulation for Level 4"""
    # In a real implementation, this would serve an actual PCAP file
    # For demo purposes, we'll provide the flag information
    return jsonify({
        'message': 'PCAP download simulation',
        'note': 'In a real implementation, this would serve a binary PCAP file',
        'packet_simulation': {
            'packet_1': 'TCP handshake',
            'packet_2': 'HTTP GET request',
            'packet_3': f'GET /api/secret?flag={FLAGS[4]} HTTP/1.1',
            'packet_4': 'HTTP response',
            'packet_5': 'TCP close'
        },
        'hint': 'Filter for HTTP traffic and examine GET requests'
    })

@app.route('/api/challenge/5', methods=['GET'])
def challenge_5():
    """Level 5: Python Logic Trap - Code analysis challenge"""
    user_id = get_or_create_session()
    
    # Check if user completed level 4
    if not user_progress[user_id]['level_4']:
        return jsonify({
            'error': 'Complete Level 4 first',
            'redirect': '/api/challenge/4'
        }), 403
    
    # Obfuscated Python code that users need to reverse engineer
    python_code = '''
def mysterious_function(x):
    """
    This function performs some mysterious calculations.
    Find the correct input to get the flag!
    """
    if len(str(x)) != 4:
        return "Wrong length!"
    
    digits = [int(d) for d in str(x)]
    
    if digits[0] * digits[1] != 12:
        return "First condition failed!"
    
    if digits[2] + digits[3] != 9:
        return "Second condition failed!"
    
    if sum(digits) != 18:
        return "Third condition failed!"
    
    # If all conditions pass, return the flag
    return "kir0{logic_wizard}"

# Test your input by calling: mysterious_function(YOUR_GUESS)
# Submit your answer to /api/submit/5
'''
    
    return jsonify({
        'level': 5,
        'title': 'Python Logic Trap',
        'description': 'Analyze the Python code and find the correct 4-digit input.',
        'hint': 'Read the conditions carefully and solve the mathematical constraints',
        'code': python_code,
        'download_url': '/api/download/mystery.py',
        'submit_endpoint': '/api/submit/5'
    })

@app.route('/api/download/mystery.py', methods=['GET'])
def download_mystery_python():
    """Download the mystery Python file for Level 5"""
    python_code = '''def mysterious_function(x):
    """
    This function performs some mysterious calculations.
    Find the correct input to get the flag!
    """
    if len(str(x)) != 4:
        return "Wrong length!"
    
    digits = [int(d) for d in str(x)]
    
    if digits[0] * digits[1] != 12:
        return "First condition failed!"
    
    if digits[2] + digits[3] != 9:
        return "Second condition failed!"
    
    if sum(digits) != 18:
        return "Third condition failed!"
    
    # If all conditions pass, return the flag
    return "kir0{logic_wizard}"

# Test your input by calling: mysterious_function(YOUR_GUESS)
# Submit your answer to /api/submit/5
'''
    
    with open('mystery.py', 'w') as f:
        f.write(python_code)
    
    return send_file('mystery.py', as_attachment=True, download_name='mystery.py')

@app.route('/api/challenge/6', methods=['GET'])
def challenge_6():
    """Bonus Level 6: Role Reversal - Auth bypass challenge"""
    user_id = get_or_create_session()
    
    # Check if user completed level 5
    if not user_progress[user_id]['level_5']:
        return jsonify({
            'error': 'Complete Level 5 first',
            'redirect': '/api/challenge/5'
        }), 403
    
    return jsonify({
        'level': 6,
        'title': 'Role Reversal (Bonus)',
        'description': 'You are a regular user, but there might be a way to access admin content...',
        'hint': 'Try accessing admin endpoints directly',
        'user_role': 'regular_user',
        'admin_endpoint': '/api/admin',
        'note': 'Sometimes security controls are not properly implemented...'
    })

@app.route('/api/admin', methods=['GET'])
def admin_endpoint():
    """Vulnerable admin endpoint for Level 6"""
    user_id = get_or_create_session()
    
    # Intentionally vulnerable - missing proper authorization check
    # In a real system, this would check user roles properly
    user_id_param = request.args.get('id', user_id)
    
    # Simulate admin access without proper validation
    return jsonify({
        'message': 'Welcome to admin panel!',
        'flag': FLAGS[6],
        'vulnerability': 'Missing access control validation',
        'user_accessed': user_id_param
    })

@app.route('/api/submit/<int:level>', methods=['POST'])
def submit_flag(level):
    """Submit flag for any level"""
    user_id = get_or_create_session()
    data = request.get_json()
    
    if not data or 'flag' not in data:
        return jsonify({
            'status': 'error',
            'message': 'Flag is required'
        }), 400
    
    submitted_flag = data['flag'].strip()
    
    # Special handling for Level 5 (accepts both the number and the flag)
    if level == 5:
        # Check if they submitted the correct number (3636)
        if submitted_flag == "3636":
            submitted_flag = FLAGS[5]  # Convert to actual flag
        # Also accept the flag directly
        elif submitted_flag == FLAGS[5]:
            pass  # Already correct
    
    if level not in FLAGS:
        return jsonify({
            'status': 'error',
            'message': 'Invalid level'
        }), 400
    
    if submitted_flag == FLAGS[level]:
        # Mark level as completed
        user_progress[user_id][f'level_{level}'] = True
        user_sessions[user_id]['completed_levels'].append(level)
        
        # Determine next level
        next_level = None
        if level < 5:
            next_level = f'/api/challenge/{level + 1}'
        elif level == 5:
            next_level = '/api/challenge/6'  # Bonus level
        
        return jsonify({
            'status': 'success',
            'message': f'Correct! Level {level} completed.',
            'flag': FLAGS[level],
            'next': next_level,
            'progress': user_progress[user_id]
        })
    else:
        return jsonify({
            'status': 'error',
            'message': 'Incorrect flag. Try again!',
            'hint': 'Double-check your analysis and try again.'
        })

@app.route('/api/progress', methods=['GET'])
def get_progress():
    """Get user's current progress"""
    user_id = get_or_create_session()
    
    return jsonify({
        'user_id': user_id,
        'progress': user_progress[user_id],
        'completed_levels': user_sessions[user_id]['completed_levels'],
        'current_level': len(user_sessions[user_id]['completed_levels']) + 1
    })

@app.route('/api/leaderboard', methods=['GET'])
def get_leaderboard():
    """Get leaderboard of all users (for hackathon fun)"""
    leaderboard = []
    
    for user_id, progress in user_progress.items():
        completed_count = sum(1 for completed in progress.values() if completed)
        leaderboard.append({
            'user_id': user_id[:8] + '...',  # Truncate for privacy
            'completed_levels': completed_count,
            'progress': progress
        })
    
    # Sort by completed levels (descending)
    leaderboard.sort(key=lambda x: x['completed_levels'], reverse=True)
    
    return jsonify({
        'leaderboard': leaderboard,
        'total_users': len(user_sessions)
    })

@app.route('/api/reset', methods=['POST'])
def reset_progress():
    """Reset user progress (for testing)"""
    user_id = get_or_create_session()
    
    # Reset progress
    user_progress[user_id] = {
        'level_1': False,
        'level_2': False,
        'level_3': False,
        'level_4': False,
        'level_5': False,
        'level_6': False
    }
    
    user_sessions[user_id]['completed_levels'] = []
    user_sessions[user_id]['current_level'] = 1
    
    return jsonify({
        'status': 'success',
        'message': 'Progress reset successfully',
        'redirect': '/api/challenge/1'
    })

@app.route('/api/hints/<int:level>', methods=['GET'])
def get_hints(level):
    """Get additional hints for each level"""
    hints = {
        1: [
            "Hidden directories start with a dot (.)",
            "Try exploring /.secret_dir/",
            "Use /api/read/ to read file contents"
        ],
        2: [
            "Look for unusual query parameters",
            "The flag is in a GET request query string",
            "Search for 'kir0{' in the log entries"
        ],
        3: [
            "EXIF data contains metadata about images",
            "Look for the Author field in the metadata",
            "Use exiftool or online EXIF viewers"
        ],
        4: [
            "Filter network traffic for HTTP requests",
            "Look for GET requests with suspicious parameters",
            "The flag is in a query parameter"
        ],
        5: [
            "Solve the mathematical constraints step by step",
            "You need a 4-digit number where: digit1 * digit2 = 12, digit3 + digit4 = 9, sum = 18",
            "Try different combinations: 3636, 4635, 6234, etc."
        ],
        6: [
            "Try accessing admin endpoints directly",
            "Sometimes authorization checks are missing",
            "Try /api/admin?id=1"
        ]
    }
    
    if level not in hints:
        return jsonify({
            'error': 'Invalid level'
        }), 400
    
    return jsonify({
        'level': level,
        'hints': hints[level]
    })

@app.route('/', methods=['GET'])
def index():
    """Welcome endpoint"""
    return jsonify({
        'message': 'Welcome to the CTF Mini-Game Backend!',
        'version': '1.0.0',
        'levels': 6,
        'start': '/api/challenge/1',
        'session': '/api/session',
        'progress': '/api/progress',
        'leaderboard': '/api/leaderboard'
    })

if __name__ == '__main__':
    # Clean up any existing temporary files
    for temp_file in ['webserver.log', 'mystery.py']:
        if os.path.exists(temp_file):
            os.remove(temp_file)
    
    print("🚀 CTF Mini-Game Backend Starting...")
    print("📍 Available endpoints:")
    print("   GET  /                     - Welcome message")
    print("   GET  /api/session          - Session info")
    print("   GET  /api/challenge/1-6    - Challenge endpoints")
    print("   POST /api/submit/<level>   - Submit flags")
    print("   GET  /api/progress         - User progress")
    print("   GET  /api/leaderboard      - Leaderboard")
    print("   GET  /api/hints/<level>    - Get hints")
    print("   POST /api/reset            - Reset progress")
    print("\n🎯 Flags:")
    for level, flag in FLAGS.items():
        print(f"   Level {level}: {flag}")
    
    app.run(debug=True, host='0.0.0.0', port=5000)
if __name__ == "__main__":
    app.run(debug=True)
